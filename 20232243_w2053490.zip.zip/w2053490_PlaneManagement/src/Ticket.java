import java.io.FileWriter;
import java.io.IOException;

public class Ticket {
    private char row;
    private int seat;
    private int price;
    private Person person;

    public Ticket(char row, int seat, int price, Person person) {
        this.row = row;
        this.seat = seat;
        this.price = price;
        this.person = person;
        save();
    }
    public void save(){
        String fileName = row + "" + seat + ".txt";
        try{
            FileWriter file = new FileWriter(fileName+".txt");
            file.write("Ticket Information:\n");
            file.write("Row: " + row + "\n");
            file.write("Seat: " + seat + "\n");
            file.write("Price: £" + price + "\n");
            file.write("Person Information:\n");
            file.write("Name: " + person.getName() + "\n");
            file.write("Surname: " + person.getSurname() + "\n");
            file.write("Email: " + person.getEmail() + "\n");
            file.close();
            System.out.println("Ticket information saved to " + fileName);
        } catch (IOException e) {
            System.out.println("An error occurred while saving the ticket information.");
            e.printStackTrace();
        }
    }

    public char getRow() {
        return row;
    }

    public void setRow(char row) {
        this.row = row;
    }

    public int getSeat() {
        return seat;
    }

    public void setSeat(int seat) {
        this.seat = seat;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    public Person getPerson() {
        return person;
    }

    public void setPerson(Person person) {
        this.person = person;
    }

    public void printTicketInfo() {
        System.out.println("Row: " + row);
        System.out.println("Seat: " + seat);
        System.out.println("Price:£" + price);
        System.out.println("Person Information:");
        person.printPersonInfo();
    }
}
