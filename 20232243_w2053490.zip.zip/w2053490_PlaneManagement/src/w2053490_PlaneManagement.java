import java.util.InputMismatchException;
import java.util.Scanner;

public class w2053490_PlaneManagement {
    static Scanner in=new Scanner(System.in);
    static int menu_option;
    static char row_letter;
    static int seat_number;
    static int row_A_seats[]=new int[14];
    static int row_B_seats[]=new int[12];
    static int row_C_seats[]=new int[12];
    static int row_D_seats[]=new int[14];
    static int [] finalRow_seat;
    static int finalSeatNum;
    static char go_main;
    static char go_close;
    static int price;

    static int ticketsCount = 0;
    static Ticket[] ticketsArray = new Ticket[52];

//This is a method for Menu option
    public static void starting(){
        System.out.println("\n********************************************************");
        System.out.println("*                     MENU OPTIONS                     *");
        System.out.println("********************************************************");
        System.out.println("1) BUY A SEAT");
        System.out.println("2) CANCEL A SEAT");
        System.out.println("3) FIND FIRST AVAILABLE SEAT");
        System.out.println("4) SHOW SEATING PLAN");
        System.out.println("5) PRINT TICKET INFORMATION AND TOTAL SALES");
        System.out.println("6) SEARCH SEAT");
        System.out.println("0) QUIT");
        System.out.println("********************************************************");
        System.out.println("Please select an option:");
        try {
            Scanner in=new Scanner(System.in);
            menu_option=in.nextInt();
            switch (menu_option){
                case 1:
                    System.out.println();
                    buy_seat();
                    break;
                case 2:
                    System.out.println();
                    cancel_seat();
                    break;
                case 3:
                    System.out.println();
                    find_first_available();
                    break;
                case 4:
                    System.out.println();
                    show_seating_plan();
                    break;
                case 5:
                    System.out.println();
                    print_tickets_info();
                    break;
                case 6:
                    System.out.println();
                    search_ticket();
                    break;
                case 0:
                    quit();
                    break;

                default:
                    starting();
            }
        }
        catch (InputMismatchException e){
            System.out.println("Incorrect Input");
            starting();

        }

    }
    public static void yORc(){
        System.out.println("Enter 'Y' for Main Option Or Enter 'C' for Close");
        go_main=in.next().charAt(0);
        if (go_main=='Y' || go_main=='y'){
            starting();
        } else if (go_close=='C' ||go_close=='c'){
            quit();
        }
    }
    public static void seatMethod(){
        for (int a_seats : row_A_seats) {
            System.out.print(a_seats + "  ");
        }
        System.out.println(" ");
        for (int b_seats : row_B_seats) {
            System.out.print(b_seats + "  ");
        } System.out.println(" ");
        for (int c_seats : row_C_seats) {
            System.out.print(c_seats + "  ");
        } System.out.println(" ");
        for (int d_seats : row_D_seats) {
            System.out.print(d_seats + "  ");
        } System.out.println(" ");
    }
    public static void quit(){
        System.out.println("Thank You for visiting Us");
        System.exit(0);
    }
    public static void pricePlan(){
        if (seat_number>=1 && seat_number<=5){
            price=200;
        } else if (seat_number>=6 && seat_number<=9) {
            price=150;
        } else if (seat_number>=10 && seat_number<=14) {
            price=180;
        }
    }
    public static void seatSelection(){
        while (true) {
            System.out.println("Enter a Row letter(A/B/C/D): ");
            row_letter = in.next().charAt(0);
            if (row_letter == 'A' || row_letter == 'a') {
                finalRow_seat = row_A_seats;

                break;
            } else if (row_letter == 'B' || row_letter == 'b') {
                finalRow_seat = row_B_seats;
                break;
            } else if (row_letter == 'C' || row_letter == 'c') {
                finalRow_seat = row_C_seats;
                break;
            } else if (row_letter == 'D' || row_letter == 'd') {
                finalRow_seat = row_D_seats;
                break;
            }
        }

        while (true) {
            try {
                System.out.println("Enter the seat number: ");
                seat_number = in.nextInt();
                if (row_letter == 'A' || row_letter == 'a') {
                    if (seat_number >= 1 && seat_number <= 14) {
                        finalSeatNum = seat_number - 1;
                        break;
                    }
                }
                if (row_letter == 'B' || row_letter == 'b') {
                    if (seat_number >= 1 && seat_number <= 12) {
                        finalSeatNum = seat_number - 1;
                        break;
                    }
                }
                if (row_letter == 'C' || row_letter == 'c') {
                    if (seat_number >= 1 && seat_number <= 12) {
                        finalSeatNum = seat_number - 1;
                        break;
                    }
                }
                if (row_letter == 'D' || row_letter == 'd') {
                    if (seat_number >= 1 && seat_number <= 14) {
                        finalSeatNum = seat_number - 1;
                        break;
                    }
                }
            } catch (InputMismatchException e) {
                System.out.println("Enter the correct seat Number");
                in.nextLine();
            }
        }
    }
   //This is a method for buy a seat.
    public static void buy_seat() {
        System.out.println("\n********************************************************");
        System.out.println("*                 BUY A SEAT                            *");
        System.out.println("********************************************************");
        seatSelection();
        if (finalRow_seat[finalSeatNum] == 0) {
            finalRow_seat[finalSeatNum] = 1;
             pricePlan();
            System.out.println("Enter Person's Name:");
            String name = in.next();
            System.out.println("Enter Person's Surname:");
            String surname = in.next();
            System.out.println("Enter Person's Email:");
            String email = in.next();

            Person person = new Person(name, surname, email);
            Ticket ticket = new Ticket(row_letter, seat_number, price, person);
            ticketsArray[ticketsCount++] = ticket;

            System.out.println("**** Your Seat has been Booked ****");


        } else {
            System.out.println("**** Your seat selection was wrong ****");
            buy_seat();
        }
        seatMethod();
        yORc();
    }
    //This is a method for cancel my seat
    public static void cancel_seat(){
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter your name:");
        String name = scanner.next();
        System.out.println("Enter your surname:");
        String surname = scanner.next();
        System.out.println("Enter your email:");
        String email = scanner.next();
        System.out.println("Enter row letter and seat number that You want to Cancel ");
        seatSelection();
        if (finalRow_seat[finalSeatNum] == 1) {
            finalRow_seat[finalSeatNum] = 0;

            for (int i=0;i<ticketsCount;i++){
                Ticket ticket = ticketsArray[i];
                if (ticket.getPerson().getName().equalsIgnoreCase(name) &&
                ticket.getPerson().getSurname().equalsIgnoreCase(surname) &&
                ticket.getPerson().getEmail().equalsIgnoreCase(email) &&
                ticket.getRow() == row_letter &&
                ticket.getSeat() == seat_number ) {
                    for (int j = 1; j <ticketsCount-1; j++){
                        ticketsArray[j]=ticketsArray[j+1];
                    }
                    ticketsCount--;
                    System.out.println("Your Seat Booking Successfully canceled");
                    break;
                }
                
            }

        } else if (finalRow_seat[finalSeatNum]==0){
            System.out.println("****** Seat is not Booked, Try Again  ******");
            cancel_seat();
        }
        yORc();
    }
    //This is a method for  first seat which is still
    //available
    public static void find_first_available(){
        boolean found = false;
        for (int i = 0; i < row_A_seats.length; i++) {
            if (row_A_seats[i] == 0) {
                System.out.println("First available seat at A " + (i + 1));
                found = true;
                break;
            }
        }
        if (!found) {
            for (int i = 0; i < row_B_seats.length; i++) {
                if (row_B_seats[i] == 0) {
                    System.out.println("First available seat at B " + (i + 1) );
                    found = true;
                    break;
                }
            }
        }
        if (!found) {
            for (int i = 0; i < row_C_seats.length; i++) {
                if (row_C_seats[i] == 0) {
                    System.out.println("First available seat at C " + (i + 1) );
                    found = true;
                    break;
                }
            }
        }
        if (!found) {
            for (int i = 0; i < row_D_seats.length; i++) {
                if (row_D_seats[i] == 0) {
                    System.out.println("First available seat at D " + (i + 1));
                    found = true;
                    break;
                }
            }
        }
        if (!found) {
            System.out.println("All Sold");
        }
    yORc();
    }
    //This is a method for shows the seats that are
    //available
    public static void show_seating_plan(){
        System.out.println("\n********************************************************");
        System.out.println("*                 SEATING PLAN DISPLAY                 *");
        System.out.println("********************************************************");

        for (int seat : row_A_seats) {
            if (seat == 0) {
                System.out.print("O  ");
            } else {
                System.out.print("X  ");
            }
        }
        System.out.println("\n");

        for (int seat : row_B_seats) {
            if (seat == 0) {
                System.out.print("O  ");
            } else {
                System.out.print("X  ");
            }
        }
        System.out.println("\n");

        for (int seat : row_C_seats) {
            if (seat == 0) {
                System.out.print("O  ");
            } else {
                System.out.print("X  ");
            }
        }
        System.out.println("\n");

        for (int seat : row_D_seats) {
            if (seat == 0) {
                System.out.print("O  ");
            } else {
                System.out.print("X  ");
            }
        }
        System.out.println("\n");

        System.out.println("********************************************************");
        yORc();
    }
    //that prints the information of all
    //tickets that have been sold
    public static void print_tickets_info(){
        int total=0;
        for(int i=0;i<ticketsCount; i++){
            Ticket ticket = ticketsArray[i];
            Person person = ticket.getPerson();
            System.out.println("Ticket number  " + (i + 1) + ":");
            person.printPersonInfo();
            ticket.printTicketInfo();
            total += ticket.getPrice();
            System.out.println("----------------------------------");
        }
        System.out.println("Total £" + total);
        yORc();
    }
public static void search_ticket(){
    seatSelection();
    boolean found = false;
    for (int i = 0; i < ticketsCount; i++) {
        Ticket ticket = ticketsArray[i];
        if (ticket.getRow() == row_letter && ticket.getSeat() == seat_number) {
            ticket.getPerson().printPersonInfo();
            ticket.printTicketInfo();
            found = true;
            break;
        }
    }
    if (!found) {
        System.out.println("This seat is Available");
    } else {
        System.out.println("** This seat is not Available **");
    }
    yORc();
    }
public static void main(String[] args) {
            System.out.println("\n********************************************************");
            System.out.println("*    WELCOME TO THE SEAT MANAGEMENT APPLICATION        *");
            System.out.println("********************************************************");
            seatMethod();
            starting();
        }

}